package student_player;


import java.util.ArrayList;

import boardgame.Board;
import bohnenspiel.BohnenspielBoard;
import bohnenspiel.BohnenspielBoardState;
import bohnenspiel.BohnenspielMove;
import bohnenspiel.BohnenspielPlayer;
import bohnenspiel.BohnenspielMove.MoveType;
import bohnenspiel.RandomBohnenspielPlayer;
import bohnenspiel.GreedyBohnenspielPlayer;

/** this class has three simulate methods
 * 1,2: between weighttest and bohnenspiel player(player1,2,random, greedy), to make sure current weight 
 * results better performance than benchmark
 * 3: between weighttest and weighttest 
 * to find out optimal weights among candidates (selected using 1,2)
 * moved from src to student_player, did not test if works correctly
 */
public class simulateGame{

	public static int simulate(weightTest p0, BohnenspielPlayer p1,double[] w){
		BohnenspielBoard board = new BohnenspielBoard();
		p0.setColor(0);
		p1.setColor(1);
	
		while (board.getWinner() == Board.NOBODY) {
			
			if (board.getTurnPlayer() == 0) {
				board.move(p0.chooseMove2((BohnenspielBoardState) board.getBoardState(),w));
				
			} else {
				board.move(p1.chooseMove(board.getBoardState()));
			}	
		}
		
		return board.getWinner();
		
		
	}
	
	public static int simulate2(weightTest p1, BohnenspielPlayer p0,double[] w){
		BohnenspielBoard board = new BohnenspielBoard();
		p0.setColor(0);
		p1.setColor(1);
	
		while (board.getWinner() == Board.NOBODY) {
			
			if (board.getTurnPlayer() == 0) {
				board.move(p0.chooseMove(board.getBoardState()));
				
			} else {
				board.move(p1.chooseMove2((BohnenspielBoardState) board.getBoardState(),w));
			}	
		}
		
		return board.getWinner();
		
	}
	
	
	public static int simulate3(weightTest p1, weightTest p0,double[] w0, double[] w1){
		BohnenspielBoard board = new BohnenspielBoard();
		p0.setColor(0);
		p1.setColor(1);
	
		while (board.getWinner() == Board.NOBODY) {
			
			if (board.getTurnPlayer() == 0) {
				board.move(p0.chooseMove2((BohnenspielBoardState) board.getBoardState(),w0));
				
			} else {
				board.move(p1.chooseMove2((BohnenspielBoardState) board.getBoardState(),w1));
			}	
		}
		
		return board.getWinner();
		
		
	}
	
	
	/** main method currently prints the result of second round tournament between weights 
	 *  commented part: benchmark testing and first round tournament  */
	public static void main(String args[]){
		//weightTest p0 = new weightTest();
		//BohnenspielPlayer p1 = new FrankPlayer();
		double[] w =new double[2];
		w[0]=0.8;
		w[1]=0.5;
		/*int winner =simulate(p0,p1,w);
		System.out.println("winner = player "+winner);*/
		
		ArrayList<double[]> d = new ArrayList<double[]>();
//		w[0]=0.7; w[1]=0.4;
//		d.add(new double[]{w[0],w[1]});
		w[0]=0.7; w[1]=1.0;
		d.add(new double[]{w[0],w[1]});
		w[0]=0.8; w[1]=0.3;
		d.add(new double[]{w[0],w[1]});
//		w[0]=0.8; w[1]=0.6;
//		d.add(new double[]{w[0],w[1]});
//		w[0]=0.9; w[1]=0.7;
//		d.add(new double[]{w[0],w[1]});
//		w[0]=0.6; w[1]=0.3;
//		d.add(new double[]{w[0],w[1]});
		w[0]=0.6; w[1]=1.0;
		d.add(new double[]{w[0],w[1]});
		
		double [] winratefrank = new double[100]; int index = 0;
		double [] winratefrankfirst = new double[100];
		double [] winraterandom = new double[100];
		double [] winrategreedy = new double[100];
		//didn't calculate i=10, j=10
//		for(int i = 1; i<=6;i++){
//			for(int j = 0;j<=10;j++){
//				
//				w[0]=i*0.1;
//				w[1] = j*0.1;
//				System.out.println("w[0] = "+w[0]+",   w[1]= "+w[1]);
//				
//				p1 = new FrankPlayer();
//				int arraysize = 1;
//				int[] win = new int[arraysize];
//				for(int k = 0;k<arraysize;k++){
//					win[k] = simulate(p0,p1,w);
//				}
//				int count = 0;
//				for(int x:win){
//					if(x == 0){count++;}
//				}
//				winratefrank[index] = count*1.0/arraysize;
//				
//				
//				win = new int[arraysize];
//				for(int k = 0;k<arraysize;k++){
//					win[k] = simulate2(p0,p1,w);
//				}
//				count = 0;
//				for(int x:win){
//					if(x == 1){count++;}
//				}
//				winratefrankfirst[index] = count*1.0/arraysize;
//				
//				
//				p1 = new StudentPlayer1();
//				win = new int[arraysize];
//				for(int k = 0;k<arraysize;k++){
//					win[k] = simulate(p0,p1,w);
//				}
//				count = 0;
//				for(int x:win){
//					if(x == 0){count++;}
//				}
//				winraterandom[index] = count*1.0/arraysize;
//				
//				
//				win = new int[arraysize];
//				for(int k = 0;k<arraysize;k++){
//					win[k] = simulate2(p0,p1,w);
//				}
//				count = 0;
//				for(int x:win){
//					if(x == 1){count++;}
//				}
//				winrategreedy[index] = count*1.0/arraysize;
//				
//				
//				
//				
//				
//				
//				System.out.println("frank: "+winratefrank[index]+",  frankfirst: "+winratefrankfirst[index]+",  old-ver: "+winraterandom[index]+",  old-ver first: "+winrategreedy[index]);
//				System.out.println();
//				
//				
//				if(winratefrank[index]==1.0 && winratefrankfirst[index]==1.0 && winraterandom[index]==1.0 && winrategreedy[index]==1.0){
//					d.add(new double[]{w[0],w[1]});
//				}
//				index++;
//			}
		
		int size = d.size();
		
		double[] score = new double[size];
		
		weightTest p0 = new weightTest();
		weightTest p1 = new weightTest();

		
		for(int i = 0; i<size; i++){
			double[] w0 = d.get(i);
			System.out.println("for weights: "+w0[0]+", "+w0[1]);
			
			for(int j = 0;j<size;j++){
				double[] w1 = d.get(j);
				int win = simulate3(p0,p1,w0,w1);
				System.out.println("against "+w1[0]+", "+w1[1]+" winner = "+win);
				if(win == 0){score[i]++;score[j]--;}
				else{score[i]--;score[j]++;}

			}
			
			System.out.println();

			
		
		
		}
		for(int i = 0; i<size;i++){
			double[] w0 = d.get(i);
			System.out.println("for weights: "+w0[0]+", "+w0[1]+", score ="+score[i] );
		}
		
		
		

		
		
	}






}
