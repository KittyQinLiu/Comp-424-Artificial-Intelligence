please grade StudentPlayer.java, this is the final version

All others are either intermediate versions or helper methods. As some of these are going to be mentioned in my report, I decided to leave them in the package.