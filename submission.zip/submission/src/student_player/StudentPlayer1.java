package student_player;

import java.util.ArrayList;

import bohnenspiel.BohnenspielBoardState;
import bohnenspiel.BohnenspielMove;
import bohnenspiel.BohnenspielPlayer;
import bohnenspiel.BohnenspielMove.MoveType;
import student_player.mytools.MyTools;


/**
 * @author Qin Liu
 * version 1
 * this is a minimax-abprune player with evaluation = score difference
 * this player beats greedy and random
 * benchmark player
 */
public class StudentPlayer1 extends BohnenspielPlayer {
	int MAX_DEPTH = 9;

    public StudentPlayer1() { super("version1"); }
    
    

    public BohnenspielMove chooseMove(BohnenspielBoardState board_state)
    {
        
        
    	ArrayList<BohnenspielMove> moves = board_state.getLegalMoves();
        BohnenspielMove move = moves.get(0);
        int turn = board_state.getTurnNumber();
        	
        	long startTime = System.currentTimeMillis();
            

        	move = minimax(board_state);
        	long endTime   = System.currentTimeMillis();
        	long totalTime = endTime - startTime;
        //	System.out.println(totalTime);
        
       
        //}


        // But since this is a placeholder algorithm, we won't act on that information.
        return move;
    }
    
    
    
    
    
    
    @SuppressWarnings("unused")
	public BohnenspielMove minimax(BohnenspielBoardState board_state){
    	
    	
    	BohnenspielMove move =new BohnenspielMove();
    	
    	ArrayList<BohnenspielMove> moves = board_state.getLegalMoves();
    	int turn = board_state.getTurnNumber();
    	int size = moves.size();
    	double[] value = new double[size];
    	for (BohnenspielMove o: moves){
    		int index = moves.indexOf(o);
    		BohnenspielBoardState cloned_board_state = (BohnenspielBoardState) board_state.clone();
            cloned_board_state.move(o);
            o.getMoveType();//move_type
            o.getPit();//int
            
            if(true){
            
            
            	int depth = MAX_DEPTH;
                double [] profit = new double[depth+1];
                for(int i = 0; i<profit.length;i++){profit[i]=-10000;}
              //value[index] = minimax_value(cloned_board_state,depth,profit);//this is minimax

                //value[index] = abprune(cloned_board_state,-10000,+10000,depth,false); //minimax with 0.7*abprune
                value[index] = abprune2(cloned_board_state,-10000,+10000,depth,false,profit); 
            }
            else{
            	MAX_DEPTH = MAX_DEPTH+2;
            	int depth = MAX_DEPTH;
                double [] profit = new double[depth+1];
                for(int i = 0; i<profit.length;i++){profit[i]=-10000;}
            	//value[index] = minimax_value(cloned_board_state,depth,profit);//this is minimax

                //value[index] = abprune(cloned_board_state,-10000,+10000,depth,false); //minimax with 0.7*abprune
                value[index] = abprune2(cloned_board_state,-10000,+10000,depth,false,profit); 
            }
                
            
            
    	}
    	
    	
    	
    	
    	
    	double max = value[0]; int max_index = 0;
    	
    	for(int i = 1; i<value.length;i++){
    		if(value[i]>max){max = value[i]; max_index = i;}
    	}
    	
    	move = moves.get(max_index);
    	
//    	System.out.println(move.toPrettyString());

    	
    	return move;
    	
    	
    }
    
    
//    public double evaluation(double[] profit){
//    	double temp = 0; int index=profit.length;
//    	for(int i = 0; i<profit.length;i++){
//    		if(profit[i]==-10000){
//    			index =i;
//    			break;
//    		}
//    	}
//    	double [] diff = new double[index-1];
//    	
//    	for(int i = 0; i<diff.length;i++){
//    		diff[i] = profit[i+1]-profit[i];
//    		}
//    	
//    	for(int i = 0;i<diff.length;i++){
//    		double power = Math.pow(2,i+1);
//    		
//    		temp = temp+diff[i]*1.0/(i+1);
//    	}
//    	return temp;
//    }
    
    
    public double evaluation(double[] profit){
    	int index=profit.length;
    	int i = 0;
    	for(i = 0; i<profit.length;i++){
    		if(profit[i]==-10000){
    			index =i-1;
    			break;
    		}
    		index = i;
    	}
    	
    	
    	return profit[index];
    }
    

    
    
    
    
    public double minimax_value(BohnenspielBoardState board_state, int depth, double[] profit){
        	
    	ArrayList<BohnenspielMove> moves = board_state.getLegalMoves();
    	int size = moves.size();
    	
    	if(depth == 0 ){    		    		
    		profit[MAX_DEPTH-depth]= (board_state.getScore(player_id)-board_state.getScore(opponent_id));
    		
    		double res = evaluation(profit);

    		return res;
    		
    	}
    	else if(size == 0){
    		
    		profit[MAX_DEPTH-depth]= (board_state.getScore(player_id)-board_state.getScore(opponent_id));
    		for(int i = MAX_DEPTH-depth+1;i<profit.length;i++){
    			profit[i]=-10000;
    		}
    		
    		double res = evaluation(profit);
    		
    		return res;    	
    	}
    	
    	profit[MAX_DEPTH-depth]=board_state.getScore(player_id)-board_state.getScore(opponent_id);
    	
    	double[] value = new double[size];
    	for (int i = 0;i<size;i++){
    		BohnenspielMove o=moves.get(i);
    		BohnenspielBoardState cloned_board_state = (BohnenspielBoardState) board_state.clone();
            cloned_board_state.move(o);
            //value[i]=0.7*minimax_value(cloned_board_state, depth-1);
            
            value[i]=minimax_value(cloned_board_state, depth-1,profit);
    	}
    	double min,max;
    	
    	if(board_state.getTurnPlayer()== opponent_id){
    		min = value[0]; 
        	
        	for(int i = 0; i<value.length;i++){
        		if(value[i]<min){min = value[i]; 

        		}
        	}
        	
        	return min;
    	}
    	else if(board_state.getTurnPlayer()== player_id){
    		max = value[0]; 
        	for(int i = 0; i<value.length;i++){
        		if(value[i]>max){max = value[i];}
        	}    	
        	return max;
    	} 
    	
    	return -10000;
    }
    
    
    
    
    public double abprune(BohnenspielBoardState board_state,double a, double b, int depth,boolean max_turn){
    	ArrayList<BohnenspielMove> moves = board_state.getLegalMoves();
    	int size = moves.size();
    	if(depth == 0 || size == 0){
    		//return board_state.getScore(player_id);
    		return board_state.getScore(player_id)-board_state.getScore(opponent_id);	
    	}
    	
    	if(max_turn){
    		double v = -10000;
    	for (BohnenspielMove o: moves){
    		BohnenspielBoardState cloned_board_state = (BohnenspielBoardState) board_state.clone();
            cloned_board_state.move(o);
            //v = max(v,abprune(child, depth-1,a,b,false))
            double temp =0.7*abprune(cloned_board_state,a,b,depth-1,false);
            if(temp>v){v = temp;}
            if(v>a){a = v;}
            if(a>=b){break;}
    	}    	
    	return v;
    	}
    	else{
    		double v = 10000;
    		for (BohnenspielMove o: moves){
    			BohnenspielBoardState cloned_board_state = (BohnenspielBoardState) board_state.clone();
                cloned_board_state.move(o);
                //v = min(v,abprune(child, depth-1,a,b,true))
                double temp = 0.7*abprune(cloned_board_state,a,b,depth-1,true);
                if(temp<v){v = temp;}
                if(v<b){b = v;}
                if(a>=b){break;}
    		}
        	return v;
    	}
    }
    
    
    public double abprune2(BohnenspielBoardState board_state,double a, double b, int depth, boolean max_turn, double[] profit){
    	ArrayList<BohnenspielMove> moves = board_state.getLegalMoves();
    	int size = moves.size();
    	if(depth == 0 ){
    		//return board_state.getScore(player_id);
    		
    		profit[MAX_DEPTH-depth]= (board_state.getScore(player_id)-board_state.getScore(opponent_id));
    		return evaluation(profit);
    		
    	}
    	else if(size == 0){
    		
    		profit[MAX_DEPTH-depth]= (board_state.getScore(player_id)-board_state.getScore(opponent_id));
    		for(int i = MAX_DEPTH-depth+1;i<profit.length;i++){
    			profit[i]=-10000;
    		}
    		
    		return evaluation(profit);
    	}
    	
    	profit[MAX_DEPTH-depth]=board_state.getScore(player_id)-board_state.getScore(opponent_id);
    	
    	if(max_turn){
    		double v = -10000;
    	for (BohnenspielMove o: moves){
    		BohnenspielBoardState cloned_board_state = (BohnenspielBoardState) board_state.clone();
            cloned_board_state.move(o);
            //v = max(v,abprune(child, depth-1,a,b,false))
            double temp =abprune2(cloned_board_state,a,b,depth-1, false, profit);
            if(temp>v){v = temp;}
            if(v>a){a = v;}
            if(a>=b){break;}
    	}    	
    	return v;
    	}
    	else{
    		double v = 10000;
    		for (BohnenspielMove o: moves){
    			BohnenspielBoardState cloned_board_state = (BohnenspielBoardState) board_state.clone();
                cloned_board_state.move(o);
                //v = min(v,abprune(child, depth-1,a,b,true))
                double temp = abprune2(cloned_board_state,a,b,depth-1, true, profit);
                if(temp<v){v = temp;}
                if(v<b){b = v;}
                if(a>=b){break;}
    		}
        	return v;
    	}
    }
    	
    	
    
    	
    	
    
    
    
    
    
    
    
}