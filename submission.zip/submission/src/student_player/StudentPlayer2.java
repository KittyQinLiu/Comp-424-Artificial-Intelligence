package student_player;

import java.util.ArrayList;

import boardgame.Move;
import bohnenspiel.BohnenspielBoardState;
import bohnenspiel.BohnenspielMove;
import bohnenspiel.BohnenspielPlayer;
import bohnenspiel.BohnenspielMove.MoveType;
import student_player.mytools.MyTools;

/**
 * @author Qin Liu
 * version 2
 * this is a minimax-abprune player with evaluation = weighted three winning factors
 * ( score difference + seed difference - # 135 pits)
 * diff with final version: no breaktie condition of --# of available moves difference--
 */

public class StudentPlayer2 extends BohnenspielPlayer {
	int MAX_DEPTH = 9;

    /** You must modify this constructor to return your student number.
     * This is important, because this is what the code that runs the
     * competition uses to associate you with your agent.
     * The constructor should do nothing else. */
    public StudentPlayer2() { super("version2"); }

    /** This is the primary method that you need to implement.
     * The ``board_state`` object contains the current state of the game,
     * which your agent can use to make decisions. See the class
bohnenspiel.RandomPlayer
     * for another example agent. */
    public BohnenspielMove chooseMove(BohnenspielBoardState board_state)
    {       	
        	//long startTime = System.currentTimeMillis();
            

    		BohnenspielMove move = minimax(board_state);
        	//long endTime   = System.currentTimeMillis();
        	//long totalTime = endTime - startTime;
        	//System.out.println(totalTime);
        
       
            return move;
    }
    
    
    
    
    
    

public BohnenspielMove minimax(BohnenspielBoardState board_state){
    	
    	
    	//BohnenspielMove move =new BohnenspielMove();
    	
    	ArrayList<BohnenspielMove> moves = board_state.getLegalMoves();
    	int size = moves.size();
    	double[] value = new double[size];
    	double[] movect = new double[size];
    	for (BohnenspielMove o: moves){
    		int index = moves.indexOf(o);
    		BohnenspielBoardState cloned_board_state = (BohnenspielBoardState) board_state.clone();
            cloned_board_state.move(o);
            int[] op_pits = cloned_board_state.getPits()[opponent_id];
            int opcount = 0;
    		for(int i = 0;i<op_pits.length;i++){if (op_pits[i] == 0) {opcount++;} }
    		movect[index] = opcount;
          
            int depth = MAX_DEPTH;
            value[index] = abprune2(cloned_board_state,-10000,+10000,depth,false);   
            	
    	}
    	
    	double max = value[0]; int max_index = 0;
    	
    	for(int i = 1; i<value.length;i++){
    		if(value[i]>max){
    			max = value[i]; 
    			max_index = i;
    		}
    		//if tied, break by favoring state with fewer legal moves for opponent 
    		//but as our evaluation policy is double calculations, should only has ties rarely 
    		else if(value[i]==max){
    			if(movect[i]>movect[max_index]){
    				max = value[i];max_index = i;
    			}
    		}
    	}
    	
    	    	
    	return moves.get(max_index);
    	
    	
    }
    

    
    
//    public double evaluation(double[] profit){
//    	int index=profit.length;
//    	int i = 0;
//    	for(i = 0; i<profit.length;i++){
//    		if(profit[i]==-10000){
//    			index =i-1;
//    			break;
//    		}
//    		index = i;
//    	}
//
//    	return profit[index];
//    }
    

    
  
	/** use alpha-beta pruning technique to calculate minimax value
	 * implemented according to pseudo code on wikipedia: alpha-beta pruning
	 * see leaf case for evaluation policy
	 * @param board_state: current BohnenspielBoardState note that this is 
     * called from minimax, which is after applying move o and result in cloned_board_state in chooseMove
     * so it's actually min player's move now
     * @param a alpha
     * @param b beta
     * @param max_turn true if max player's turn, false min
     * @return double minimax_value of the move */
    
    public double abprune2(BohnenspielBoardState board_state,double a, double b, int depth, boolean max_turn){
    	ArrayList<BohnenspielMove> moves = board_state.getLegalMoves();
    	// leaf
    	if(depth == 0 || moves.size() ==0){
    		/* evaluation function is basically here 
    		 * evaluation = weighted three winning factors
    		 * ( score difference + seed difference - # 135 difference)
    		 * score diff = my current score - op current score
    		 * seed diff = total # of seeds in my pits - in op pits
    		 * # 135 pits= # pits with 1 or 3 or 5 beans on the board, want to minimize this 
    		 * so that in the next turn, the other player have less possibility to capture seeds
    		 * */
    		int[][] pits = board_state.getPits();
            int[] my_pits = pits[player_id];
            int[] op_pits = pits[opponent_id];
            int seedscore=0; //#135 pits 
            int mycount= 0; int opcount = 0; //mycount-opcount is seed diff
    		for(int i = 0;i<my_pits.length;i++){
    			if (my_pits[i] ==1 || my_pits[i] ==3 || my_pits[i] ==5) {seedscore++;}
    			mycount = mycount + my_pits[i];
    			
    			if (op_pits[i] ==1 || op_pits[i] ==3 || op_pits[i] ==5) {seedscore++;}
    			opcount = opcount + op_pits[i];    		
    		}
    		
    		return (0.7*(board_state.getScore(player_id)-board_state.getScore(opponent_id))+(1-0.7)*(mycount-opcount)-1.0*seedscore);

    	}
    	
    	//not leaf, then recurse
    	if(max_turn){
    		double v = -10000;
    	for (BohnenspielMove o: moves){
    		BohnenspielBoardState cloned_board_state = (BohnenspielBoardState) board_state.clone();
            cloned_board_state.move(o);
            double temp =abprune2(cloned_board_state,a,b,depth-1, false);
            if(temp>v){v = temp;}
            if(v>a){a = v;}
            if(a>=b){break;}
    	}    	
    	return v;
    	}
    	else{
    		double v = 10000;
    		for (BohnenspielMove o: moves){
    			BohnenspielBoardState cloned_board_state = (BohnenspielBoardState) board_state.clone();
                cloned_board_state.move(o);
                double temp = abprune2(cloned_board_state,a,b,depth-1, true);
                if(temp<v){v = temp;}
                if(v<b){b = v;}
                if(a>=b){break;}
    		}
        	return v;
    	}
    }

    	
    
    
    
    
    
    
    
}