package student_player;

import java.util.ArrayList;

import boardgame.Move;
import bohnenspiel.BohnenspielBoardState;
import bohnenspiel.BohnenspielMove;
import bohnenspiel.BohnenspielPlayer;
import bohnenspiel.BohnenspielMove.MoveType;
import student_player.mytools.MyTools;

/** this is a weightTest player, which is the same algorithm as version 2 
 *  chooseMove is replaced by chooseMove2 to add an extra param: double[]w weights for winning factors
 *  by initializing this player and call from simulateGame.java to play with different weights
 *  we are able to find out the optimal weights.
 */
public class weightTest extends BohnenspielPlayer {
	int MAX_DEPTH = 9;

    /** You must modify this constructor to return your student number.
     * This is important, because this is what the code that runs the
     * competition uses to associate you with your agent.
     * The constructor should do nothing else. */
    public weightTest() { super("weighttest"); }

    /** This is the primary method that you need to implement.
     * The ``board_state`` object contains the current state of the game,
     * which your agent can use to make decisions. See the class
bohnenspiel.RandomPlayer
     * for another example agent. */
    public BohnenspielMove chooseMove2(BohnenspielBoardState board_state, double[] w)
    {
        
        
    	ArrayList<BohnenspielMove> moves = board_state.getLegalMoves();
        BohnenspielMove move = moves.get(0);        	
        	//long startTime = System.currentTimeMillis();
            

        	move = minimax(board_state, w);
        	//long endTime   = System.currentTimeMillis();
        	//long totalTime = endTime - startTime;
        	//System.out.println(totalTime);
        
       
            return move;
    }
    
    
    
    
    
    

	public BohnenspielMove minimax(BohnenspielBoardState board_state, double[] w){
    	
    	
    	BohnenspielMove move =new BohnenspielMove();
    	
    	ArrayList<BohnenspielMove> moves = board_state.getLegalMoves();
    	int turn = board_state.getTurnNumber();
    	int size = moves.size();
    	double[] value = new double[size];
    	for (BohnenspielMove o: moves){
    		int index = moves.indexOf(o);
    		BohnenspielBoardState cloned_board_state = (BohnenspielBoardState) board_state.clone();
            cloned_board_state.move(o);

            	int depth = MAX_DEPTH;
                double [] profit = new double[depth+1];
                for(int i = 0; i<profit.length;i++){profit[i]=-10000;}
                value[index] = abprune2(cloned_board_state,-10000,+10000,depth,false,profit,w);     
                
    	}
    	
    	
    	
    	
    	
    	double max = value[0]; int max_index = 0;
    	
    	for(int i = 1; i<value.length;i++){
    		if(value[i]>max){max = value[i]; max_index = i;}
    	}
    	
    	move = moves.get(max_index);
    	
    	return move;
    	
    	
    }
    

    
    
    public double evaluation(double[] profit){
    	int index=profit.length;
    	int i = 0;
    	for(i = 0; i<profit.length;i++){
    		if(profit[i]==-10000){
    			index =i-1;
    			break;
    		}
    		index = i;
    	}
    	
    	
    	return profit[index];
    }
    

    
  
    
    
    
    
    public double abprune2(BohnenspielBoardState board_state,double a, double b, int depth, boolean max_turn, double[] profit, double[] w){
    	ArrayList<BohnenspielMove> moves = board_state.getLegalMoves();
    	int size = moves.size();
    	if(depth == 0 ){
    		int[][] pits = board_state.getPits();
            int[] my_pits = pits[player_id];
            int[] op_pits = pits[opponent_id];
            int seedscore=0; int mycount= 0; int opcount = 0;
    		for(int i = 0;i<my_pits.length;i++){
    			if (my_pits[i] ==1 || my_pits[i] ==3 || my_pits[i] ==5) {seedscore++;}
    			mycount = mycount + my_pits[i];
    			
    			if (op_pits[i] ==1 || op_pits[i] ==3 || op_pits[i] ==5) {seedscore++;}
    			opcount = opcount + op_pits[i];    		
    		}
    		
    		
    		profit[MAX_DEPTH-depth]= w[0]*(board_state.getScore(player_id)-board_state.getScore(opponent_id))+(1-w[0])*(mycount-opcount)-w[1]*seedscore;
    		return evaluation(profit);
    		
    	}
    	else if(size == 0){
    		
    		int[][] pits = board_state.getPits();

            // Use ``player_id`` and ``opponent_id`` to get my pits and opponent pits.
            int[] my_pits = pits[player_id];
            int[] op_pits = pits[opponent_id];
            int seedscore=0;int mycount= 0; int opcount = 0;
            for(int i = 0;i<my_pits.length;i++){
            	if (my_pits[i] ==1 || my_pits[i] ==3 || my_pits[i] ==5) {seedscore++;}
    			mycount = mycount + my_pits[i];
    			
    			if (op_pits[i] ==1 || op_pits[i] ==3 || op_pits[i] ==5) {seedscore++;}
    			opcount = opcount + op_pits[i]; 
            }
    		
    		
    		profit[MAX_DEPTH-depth]= w[0]*(board_state.getScore(player_id)-board_state.getScore(opponent_id))+(1-w[0])*(mycount-opcount)-w[1]*seedscore;
    		for(int i = MAX_DEPTH-depth+1;i<profit.length;i++){
    			profit[i]=-10000;
    		}
    		
    		return evaluation(profit);
    	}
    	
    	profit[MAX_DEPTH-depth]=board_state.getScore(player_id)-board_state.getScore(opponent_id);
    	
    	if(max_turn){
    		double v = -10000;
    	for (BohnenspielMove o: moves){
    		BohnenspielBoardState cloned_board_state = (BohnenspielBoardState) board_state.clone();
            cloned_board_state.move(o);
            double temp =abprune2(cloned_board_state,a,b,depth-1, false, profit,w);
            if(temp>v){v = temp;}
            if(v>a){a = v;}
            if(a>=b){break;}
    	}    	
    	return v;
    	}
    	else{
    		double v = 10000;
    		for (BohnenspielMove o: moves){
    			BohnenspielBoardState cloned_board_state = (BohnenspielBoardState) board_state.clone();
                cloned_board_state.move(o);
                double temp = abprune2(cloned_board_state,a,b,depth-1, true, profit,w);
                if(temp<v){v = temp;}
                if(v<b){b = v;}
                if(a>=b){break;}
    		}
        	return v;
    	}
    }

	@Override
	public Move chooseMove(BohnenspielBoardState board_state) {
		// TODO Auto-generated method stub
		return null;
	}
    	
    	
    	
    
    
    
    
    
    
    
}